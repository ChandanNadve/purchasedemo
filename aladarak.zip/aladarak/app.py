import streamlit as st
import plotly.express as px
import pandas as pd
import os
import warnings
import calendar
import base64
from datetime import datetime
import data.data_load as data_load
import src.purchase.purchase_db as purchase_db
import src.hr.hr_db as hr_db
import utils.login_page as login
from email.mime.text import MIMEText

warnings.filterwarnings('ignore')
st.set_page_config(page_title="Dashboard", page_icon=":bar_chart:", layout="wide")

def load_css(file_name: str):
    with open(file_name) as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

load_css('style.css')

# --- INITIALIZE SESSION STATE VARIABLES ---
# This is the key fix for the error. These variables are now guaranteed to exist.
if 'USERS' not in st.session_state:
    st.session_state.USERS = None  # Initialize to a default value, e.g., None or an empty list.
if 'logged_in' not in st.session_state:
    st.session_state.logged_in = False
if 'role' not in st.session_state:
    st.session_state.role = ""

class InfowayApp():
    def __init__(self):
        pass

    def dashboard(self):
        with st.sidebar:
            st.markdown(
                """
                <div style='text-align: left;'>
                    <marquee style='width: 100%; color: green; font-size: 24px; font-weight: bold;'>
                        Welcome to Al Adarak! </marquee>
                </div>
                """,
                unsafe_allow_html=True
            )
            
            if st.button("🛒 Purchase"):
                st.session_state.main_menu = "🛒Purchase"
            if st.button("👥 HR"):
                st.session_state.main_menu = "👥HR"
            if st.sidebar.button("🚪 Logout"):
                st.session_state.logged_in = False
                st.session_state.username = ""
                st.session_state.role = ""
                login.login()
                st.success("Logout Successfully")
                st.rerun() 
                

        # --- Default selection if not set ---
        if "main_menu" not in st.session_state:
            st.session_state.main_menu = "🛒Purchase"  # default menu

        # --- Load dashboards based on menu ---
        if st.session_state.main_menu == "🛒Purchase":
            grn_data, lpo_data, lpo_grn_gross_amount, lpo_grn_net_values = data_load.load_data_purchase()
            purchase_db.purchase_dashboard(grn_data, lpo_data, lpo_grn_gross_amount, lpo_grn_net_values)

        elif st.session_state.main_menu == "👥HR":
            total_employee_strength_data, in_out_strength, visa_expiry, employee_strength_data, department = data_load.load_data_hr()
            hr_db.hr_dashboard(total_employee_strength_data, in_out_strength, visa_expiry, employee_strength_data, department)

    def run(self):
        # The check below is now safe because 'USERS' is initialized above.
        """if not st.session_state.USERS:
            # Assuming 'USERS' is populated by a function in your login module
            # If not, you might need to add a call to load the user data here.
            st.warning("User data not loaded. Please set st.session_state.USERS.")
            return"""
        if 'USERS' not in st.session_state or st.session_state.USERS is None:
            st.session_state.USERS = {}
        if st.session_state.logged_in:
            role = st.session_state.role.strip().lower()

            if role == "admin":
                self.dashboard()
            elif role:
                self.dashboard()
            else:
                st.warning("No dashboard found")
        else:
            login.login()

if __name__ == "__main__":
    app = InfowayApp()
    app.run()
