MV_DEPTSTRENGTH = """select 
MONTH,
YEAR,
EMPDEPT,
TOTAL,
NCATEGORY
from MV_DEPTSTRENGTH"""

MV_GRN_DATA = """SELECT PROJECTCODE as "Project",YEAR as "Year",MONTH as "Month",GRNAMOUNT as "Amount" FROM MV_GRN_DATA"""

MV_LPODATA="""select YEARLY as "Year",MONTHLY as "Month",PROJECT as "Project",AMOUNT as "Amount" from MV_LPODATA"""

MV_LPO_GRN_DATA="""select PROJECTCODE as "Project",PO_VALUE  as "PO_Value",GRN_VALUE as "GRN_Value" from MV_LPO_GRN_DATA"""

MV_LPO_GRN_NETVALUE="""select projectcode as "Project",po_net_value as "PO_Value",grn_net_value as "GRN_Value" from mv_lpo_grn_netvalue"""


MV_EMPSTRENGTH="""select COMPANY,EMPMAINCAT,NATIONALITY,YEAR,MONTH, MM,STRENGTH from MV_EMPSTRENGTH"""
MV_INOUT_STRENGTH="""select EMPMAINCAT,YEARLY as "Year",MONTHLY,TYPE,STRENGTH as "Total_Strength" from MV_INOUT_STRENGTH"""

MV_VISA_EXPIRY="""SELECT EMPLOYEE_TYPE as "Employee_Type",EMPMAINCAT as "Employee_Category",YEARLY as "Expiry_Year",MONTHLY as "Expiry_Month",TOTAL_EMP as "Total_by_Month" FROM MV_VISA_EXPIRY"""