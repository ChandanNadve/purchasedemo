import oracledb
import pandas as pd
import warnings

warnings.filterwarnings('ignore')

db_username='adk2011'
db_password='log'
db_host='172.11.0.90'
db_port=1521
db_service='orcl'

def fetch_sql_data(query_string):
    with oracledb.connect(user=db_username, password=db_password, host=db_host, port=db_port, service_name=db_service) as connection:
        with connection.cursor() as cursor:
           return pd.read_sql(query_string,connection)
