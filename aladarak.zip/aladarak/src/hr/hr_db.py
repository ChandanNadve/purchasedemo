import streamlit as st
import plotly.express as px
import pandas as pd
import os
import warnings
import calendar
import base64
from datetime import datetime


def report_title(report_name):
    # Load local image and convert to base64
    image_path = "images/Aladrak.png"  # Adjust the path to your image
    with open(image_path, "rb") as f:
        img_base64 = base64.b64encode(f.read()).decode()

    st.markdown(
        f"""
        <style>
        .dashboard-header {{
            display: flex;
            align-items: center;
            justify-content: space-between; /* push text left, image right */
            font-size: 2rem;
            font-weight: 700;
            color: green;  /* text in blue */
            padding: 0.3rem 2rem;
            border-radius: 12px;
            background: rgb(226, 252, 231);
            box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.3);
            margin-bottom: 0.5rem;
        }}
        .dashboard-header img {{
            height: 40px; /* adjust size */
            width: auto;
        }}
        </style>

        <div class="dashboard-header">
            <span>{report_name}</span>
            <img src="data:image/png;base64,{img_base64}" alt="Logo">
        </div>
        """,
        unsafe_allow_html=True
    )

def hr_dashboard(total_employee_strength_data,in_out_strength,visa_expiry,employee_strength_data,department):
    report_title("HR Dashboard")
    tab10,tab11,tab12,tab13,tab14 = st.tabs(["👥Yearly Strength","👥Monthly Strength ","🔃In and Out","📑Visa Expiry","🏢Department-wise"])
    
    with tab10:
        # Put HR charts, filters, metrics here
        # --- Ensure numeric Year first ---
        total_employee_strength_data["YEAR"] = total_employee_strength_data["YEAR"].astype(int)

        total_employee_strength_data = total_employee_strength_data[total_employee_strength_data["YEAR"] >= 2013]
        col3P,col33P=st.columns([1.5,3])
       
        with col3P.popover("⚙️ Show Filters"):

                # --- Ensure numeric Year ---
                
                # --- Sorted unique years ---
                year_list = sorted(total_employee_strength_data['YEAR'].unique())

                    # --- Use select_slider for year range ---
                start_year, end_year = st.select_slider(
                "Select Year Range",options=year_list,value=(year_list[0], year_list[-1]),
                key="year_range_slider")

               

                filtered_data = total_employee_strength_data[(total_employee_strength_data['YEAR'] >= start_year) &(total_employee_strength_data['YEAR'] <= end_year)].copy()

                # Convert datatypes after filtering (not before)
                filtered_data["YEAR"] = filtered_data["YEAR"].astype(int)
                filtered_data["STRENGTH"] = (
                    filtered_data["STRENGTH"].astype(str).str.replace(",", "").astype(int)
                )

                # Yearly strength (use filtered data!)
                yearly_strength = filtered_data[filtered_data['MONTH'] == 'DECEMBER']
                yearly_strength = yearly_strength.groupby('YEAR')['STRENGTH'].sum().reset_index()

        
        
        
        yearly_strength = (yearly_strength.groupby('YEAR')['STRENGTH'].sum().reset_index())
       
           
        if "selected_year" not in st.session_state:
           st.session_state.selected_year = None
        if st.session_state.selected_year is None:
             
            fig_hr = px.bar(yearly_strength,
            x="YEAR",
            y="STRENGTH",
            text_auto=True,
            title = f"Total Employee Strenght - Yearly({start_year}-{end_year})",
            color_discrete_sequence=["#006400"] 
           )
        
            fig_hr.update_xaxes(
            tickmode='array', 
            tickvals=yearly_strength['YEAR'], 
            ticktext=yearly_strength['YEAR'])

        else:
        # Show monthly chart for selected year
            monthly_strength = (total_employee_strength_data[total_employee_strength_data['YEAR'] == st.session_state.selected_year].groupby('MONTH')['STRENGTH'].sum().reset_index())

            month_order = ["JANUARY","FEBRUARY","MARCH","APRIL","MAY","JUNE","JULY",
                    "AUGUST","SEPTEMBER","OCTOBER","NOVEMBER","DECEMBER"]
            monthly_strength['MONTH'] = pd.Categorical(monthly_strength['MONTH'], categories=month_order, ordered=True)
            monthly_strength = monthly_strength.sort_values('MONTH')

            fig_hr = px.bar(
            monthly_strength,
            x="MONTH",
            y="STRENGTH",
            text_auto=True,
            title=f"Total Employee Strength - Monthly ({st.session_state.selected_year})",
            color_discrete_sequence=["#000064"]
            )

    
        clicked = st.plotly_chart(fig_hr, use_container_width=True, key="employee_strength", on_select="rerun")

        # Capture clickData
        if clicked and clicked["selection"]["points"]:
                clicked_year = clicked["selection"]["points"][0].get("x")
                if st.session_state.selected_year is None and clicked_year:
                    st.session_state.selected_year = int(clicked_year)
                    st.rerun()

            # Add a "Back" button for going back to yearly view
        if st.session_state.selected_year is not None:
                col1,col2=st.columns([1,10])
                if col1.button("⬅ Back to Yearly View"):
                    st.session_state.selected_year = None
                    st.rerun()
                fig_hr.update_layout(
                    autosize=True,
                    height=500   # 👈 match the CSS height
                )

        # Always render chart here (position fixed)
        #chart_placeholder = st.empty()
        #chart_placeholder.plotly_chart(fig_hr, use_container_width=True)
        

    with tab11:
        # Filter only LABOUR
        labour_data = total_employee_strength_data[total_employee_strength_data["EMPMAINCAT"] == "LABOUR"]
        

        # Group by YEAR & MM (MM is numeric month)
        monthly_labour_strength = (
            labour_data.groupby(["YEAR", "MM"])["STRENGTH"]
            .sum()
            .reset_index()
        )

        # Ensure MM is zero-padded (01, 02, … 12)
        monthly_labour_strength["MM"] = monthly_labour_strength["MM"].astype(str).str.zfill(2)
        monthly_labour_strength = monthly_labour_strength[monthly_labour_strength["YEAR"] >= 2013]

        # Create YearMonth column (YYYY-MM)
        monthly_labour_strength["YearMonth"] = monthly_labour_strength["YEAR"].astype(str) + "-" + monthly_labour_strength["MM"]

        # Sort by YearMonth
        monthly_labour_strength = monthly_labour_strength.sort_values(by="YearMonth")

      
        col4P,col44P=st.columns([1.5,3])
        with col4P.popover("⚙️ Show Filters"):
                   
                    monthly_labour_strength['YEAR'] = monthly_labour_strength['YEAR'].astype(int)
                    year_list = sorted(monthly_labour_strength['YEAR'].unique())

                    start_year, end_year = st.select_slider(
                        "Select Year Range",
                        options=year_list,value=(year_list[0], year_list[-1]))
        monthly_labour_strength_filtered = monthly_labour_strength[(monthly_labour_strength["YEAR"] >= start_year)& (monthly_labour_strength["YEAR"] <= end_year)]
          # Plot
        fig_labour = px.bar(
            monthly_labour_strength_filtered,
            x="YearMonth",      # X-axis = Year-Month
            y="STRENGTH",       # Y-axis = Labour Strength
            text_auto=True,title = f"Monthly LABOUR Strength({start_year}-{end_year})",
            color_discrete_sequence=["#006400"] )
    

        # Layout
        fig_labour.update_layout(
            xaxis_title="Year-Month",
            yaxis_title="LABOUR Strength"
        )

        fig_labour.update_layout(
                autosize=True,
                height=500   # 👈 match the CSS height
            )
                    
        st.plotly_chart(fig_labour, use_container_width=True)
        
       
    with tab12:

        in_out_strength["Year"] = pd.to_numeric(in_out_strength["Year"], errors="coerce")
        in_out_strength = in_out_strength.dropna(subset=["Year"])
        in_out_strength = in_out_strength[in_out_strength["Year"] >= 2013]
        

        # Convert year to int
        in_out_strength["Year"] = in_out_strength["Year"].astype(int)

        # Group
        in_out_strength = (
            in_out_strength.groupby(["Year","Type"])["Total_Strength"].sum().reset_index()
        )

        # Sort by Year
        in_out_strength = in_out_strength.sort_values("Year")

        col5P,col54P=st.columns([1.5,3])
        with col5P.popover("⚙️ Show Filters"):
                   
                    in_out_strength['Year'] = in_out_strength['Year'].astype(int)
                    year_list = sorted(in_out_strength['Year'].unique())

                    start_year, end_year = st.select_slider(
                        "Select Year Range",
                        options=year_list,value=(year_list[0], year_list[-1]))
        in_out_strength_filtered = in_out_strength[(in_out_strength["Year"] >= start_year)& (in_out_strength["Year"] <= end_year)]
        

        # --- Create bar chart ---
        fig_in_out = px.bar(
            in_out_strength_filtered,
            x="Year",
            y="Total_Strength",
            color="Type",  # IN vs OUT
            barmode="group", text_auto=True,
            title=f"Yearly Employee Strength (IN vs OUT)({start_year}-{end_year})",
            text="Total_Strength",color_discrete_sequence=["#006400", "#90EE90"]
        )
        fig_in_out.update_layout(
                autosize=True,
                height=500   # 👈 match the CSS height
            )
        # Better layout
        fig_in_out.update_traces(textposition="outside")
        fig_in_out.update_xaxes(type='category')  # force discrete x-axis

        st.plotly_chart(fig_in_out, use_container_width=True)
        
        # Remove any trailing spaces in column names
    
    #fig_visa.update_layout(autosize=True,height=500  )
    
    with tab13:
        visa_expiry.columns = visa_expiry.columns.str.strip()
        visa_expiry['Employee_Type'] = visa_expiry['Employee_Type'].str.strip().str.upper()

        # Filter for years > 2013 and < 2026
        # Convert month names to numbers
        month_map = {
        "JAN": 1, "FEB": 2, "MAR": 3, "APR": 4,
        "MAY": 5, "JUN": 6, "JUL": 7, "AUG": 8,
        "SEP": 9, "OCT": 10, "NOV": 11, "DEC": 12
        }
        visa_expiry['Expiry_Month'] = visa_expiry['Expiry_Month'].str.strip().str.upper().map(month_map)

    # Filter for years 2024 and 2025
        visa_expiry = visa_expiry[(visa_expiry['Expiry_Year'] > 2022) & (visa_expiry['Expiry_Year'] < 2026)]

    # Create Year_Month column
        visa_expiry['Year_Month'] = (visa_expiry['Expiry_Year'].astype(int).astype(str) + '-' + visa_expiry['Expiry_Month'].astype(int).astype(str).str.zfill(2))
        visa_expiry = visa_expiry.sort_values(by=['Expiry_Year', 'Expiry_Month'])

        col6P,col64P=st.columns([1.5,3])
        with col6P.popover("⚙️ Show Filters"):
                   
                    visa_expiry['Expiry_Year'] = visa_expiry['Expiry_Year'].astype(int)
                    year_list = sorted(visa_expiry['Expiry_Year'].unique())

                    start_year, end_year = st.select_slider(
                        "Select Year Range",
                        options=year_list,value=(year_list[0], year_list[-1]))
                    
        visa_expiry_filtered = visa_expiry[(visa_expiry["Expiry_Year"] >= start_year) & (visa_expiry["Expiry_Year"] <= end_year)]
        
        fig_visa = px.bar(
            visa_expiry_filtered,
            x='Year_Month',
            y='Total_by_Month',
            color='Employee_Type', text_auto=True,
            title=f'Visa Expiry Report({start_year}-{end_year})',color_discrete_sequence=["#006400", "#90EE90","#228B22"])

        st.plotly_chart(fig_visa, use_container_width=True)

    with tab14:
        department = department[department["YEAR"] >= 2013]

        dept_yearly = (department.groupby(["YEAR", "EMPDEPT"])["TOTAL"].sum().reset_index())

        col14A,col14B,col14c,col14d=st.columns([1,1,1,1])
        with col14A.popover("⚙️ Show Filters"):
                   
            department['YEAR'] = department['YEAR'].astype(int)
            year_list = sorted(department['YEAR'].unique(),reverse=True)

            current_year = datetime.now().year

            if current_year in year_list:
                default_index = year_list.index(current_year)
            else:
                default_index = 0   # pick most recent year
            selected_year = st.selectbox("Select Year",options=year_list,index=default_index,key="dept_year_selectbox")

        with col14B:  
            dept_yearly = dept_yearly[dept_yearly["YEAR"] == selected_year]
            dept_yearly=(dept_yearly.groupby(["EMPDEPT"])["TOTAL"].sum().reset_index())
            total_employees = dept_yearly["TOTAL"].sum()
            st.metric(label="👥 Total Employees", value=total_employees)

            department_selected = department[department["YEAR"] == selected_year]
            nationality_grouped = (department_selected.groupby("NCATEGORY")["TOTAL"].sum().reset_index()    )

            total_omani = nationality_grouped.loc[nationality_grouped["NCATEGORY"] == "Omani", "TOTAL"].sum()
            total_expat = nationality_grouped.loc[nationality_grouped["NCATEGORY"] == "Expat", "TOTAL"].sum()

        with col14c:
            st.metric(label="👥 Total Omani Employees", value=int(total_omani))
        with col14d:
            st.metric(label="🌍 Total Expat Employees", value=int(total_expat))

# Filter dataset  #Total_Count
        col14a,col14b=st.columns([1,1])
        with col14a:
       
           

            fig_dept_yearly = px.bar(
                dept_yearly,
                x="EMPDEPT",
                y="TOTAL",
                barmode="group",
                text_auto=True,
                title=f"Department-wise Employee Strength -{selected_year}"
            )
            st.plotly_chart(fig_dept_yearly, use_container_width=True)
        with col14b:
            fig_dept_pie = px.pie(
                dept_yearly,
                names="EMPDEPT",
                values="TOTAL",
                hole=0.4,
                title=f"Department Composition-{selected_year}"
            )
            st.plotly_chart(fig_dept_pie, use_container_width=True)

