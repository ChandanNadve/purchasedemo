import streamlit as st
import plotly.express as px
import pandas as pd
import os
import warnings
import calendar
import base64
from datetime import datetime


def report_title(report_name):
    # Load local image and convert to base64
    image_path = "images/Aladrak.png"  # Adjust the path to your image
    with open(image_path, "rb") as f:
        img_base64 = base64.b64encode(f.read()).decode()

    st.markdown(
        f"""
        <style>
        .dashboard-header {{
            display: flex;
            align-items: center;
            justify-content: space-between; /* push text left, image right */
            font-size: 2rem;
            font-weight: 700;
            color: green;  /* text in blue */
            padding: 0.3rem 2rem;
            border-radius: 12px;
            background: rgb(226, 252, 231);
            box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.3);
            margin-bottom: 0.5rem;
        }}
        .dashboard-header img {{
            height: 40px; /* adjust size */
            width: auto;
        }}
        </style>

        <div class="dashboard-header">
            <span>{report_name}</span>
            <img src="data:image/png;base64,{img_base64}" alt="Logo">
        </div>
        """,
        unsafe_allow_html=True
    )

def purchase_dashboard(grn_data, lpo_data, lpo_grn_gross_amount, lpo_grn_net_values):
    report_title("Purchase Dashboard")
    tab1, tab2, tab5,tab6 = st.tabs([
        "📊 LPO Dashboard",
        "🌍 GRN Dashboard",
        "🏗️ Projectwise Gross Purchase",
        "🏗️ Projectwise Net Purchase"
    ])

    

    total_lpo = lpo_data["Amount"].sum()
    total_grn = grn_data["Amount"].sum()
    difference = total_lpo - total_grn

    with tab1:
        col1P, Col1AP,Col1AQ, col2P = st.columns([1.4, 1.5,3, 2])

        with col1P.popover("⚙️ Show Filters"):

            # --- Ensure numeric Year ---
            lpo_data['Year'] = lpo_data['Year'].astype(int)

            # --- Sorted unique years ---
            year_list = sorted(lpo_data['Year'].unique())

            # --- Use select_slider for year range ---
            start_year, end_year = st.select_slider(
                "Select Year Range",
                options=year_list,
                value=(year_list[0], year_list[-1])
            )
        lpo_data_filtered = lpo_data[(lpo_data['Year'] >= start_year) & (lpo_data['Year'] <= end_year)]

        view_option = col2P.radio("Select View", ["Yearly", "Monthly"], horizontal=True)

        if view_option == "Yearly":
                lpo_pur_year = lpo_data_filtered.groupby('Year')['Amount'].sum().reset_index()
                lpo_pur_year['Year'] = lpo_pur_year['Year'].astype(int).astype(str)
                lpo_pur_year_kpi=lpo_pur_year['Amount'].sum()
                lpo_pur_year['Amount'] = (lpo_pur_year['Amount'] / 1_000_000).round(1)
                Col1AP.metric("Total LPO Amount", f"{lpo_pur_year_kpi/1_000_000:,.2f} M")

                # Bar chart
                fig_bar = px.bar(lpo_pur_year,x='Year',y='Amount',text_auto=True, title=f'LPO Value OMR (in millions) - Yearly({start_year}-{end_year})',
                color_discrete_sequence=["#006400"]  # light green
                )
                fig_bar.update_xaxes(
                    tickmode='array', 
                    tickvals=lpo_pur_year['Year'], 
                    ticktext=lpo_pur_year['Year']
                )
                fig_bar.update_yaxes(tickformat=",")

                # Pie chart
                fig_pie = px.pie(
                    lpo_pur_year, 
                    names='Year', 
                    values='Amount',
                    title='Net Amount LPO',
                    hole=0.4,   # donut style
                    color_discrete_sequence=px.colors.sequential.Greens
                )
                fig_pie.update_traces(textinfo='percent+label')

        elif view_option == "Monthly":
                current_year = datetime.now().year
                st.session_state.year_range = (current_year, current_year)
                lpo_pur_month = lpo_data_filtered.groupby(['Year', 'Month'])['Amount'].sum().reset_index()
                lpo_pur_month['Amount'] = (lpo_pur_month['Amount'] / 1_000_000).round(1)
                lpo_pur_month['MonthName'] = lpo_pur_month['Month'].apply(lambda x: calendar.month_abbr[int(x)])
                lpo_pur_month['MonthName'] = pd.Categorical(
                    lpo_pur_month['MonthName'],
                    categories=[calendar.month_abbr[i] for i in range(1, 13)],
                    ordered=True             )
                
                lpo_pur_month['YearMonth'] = lpo_pur_month['Year'].astype(str) + "-" + lpo_pur_month['MonthName'].astype(str)

                # Stacked bar chart
                fig_bar = px.bar(
                    lpo_pur_month,
                    x='Year',
                    y='Amount',
                    color='MonthName',
                    text='Amount',
                    title='LPO Value OMR (in millions) - Yearly (Stacked by Month)',
                    barmode='stack'
                )
                fig_bar.update_layout(
                    xaxis_title="Year",
                    yaxis_title="Amount (in millions)",
                    barmode='stack'
                )

                # Pie chart
                fig_pie = px.pie(
                    lpo_pur_month, 
                    names='YearMonth', 
                    values='Amount',
                    title='Net Amount LPO (Monthly)',
                    hole=0.4,
                    color_discrete_sequence=px.colors.sequential.Greens
                )
                fig_pie.update_traces(textinfo='percent+label')

            # Display charts
        col1, col2 = st.columns([3,2])
        with col1:
                clicked = st.plotly_chart(fig_bar, use_container_width=True)
        with col2:
                st.plotly_chart(fig_pie, use_container_width=True)

        lpo_pur_year_month = lpo_data.groupby(['Year', 'Month'])['Amount'].sum().reset_index()

                    # Convert numeric months to names
        if lpo_pur_year_month['Month'].dtype != object:
                        lpo_pur_year_month['Month'] = lpo_pur_year_month['Month'].apply(lambda x: calendar.month_abbr[int(x)])

        lpo_pur_year_month['YearMonth'] = lpo_pur_year_month['Year'].astype(str) + "-" + lpo_pur_year_month['Month']

        lpo_pur_year_month['Amount'] = (lpo_pur_year_month['Amount'] / 1_000_000).round(1)

        fig_bar2 = px.bar( lpo_pur_year_month, x='YearMonth',y='Amount', text_auto=True)
        fig_bar2.update_yaxes(tickformat=",") 

    

    with tab2:
        total_grn = grn_data["Amount"].sum()
        col3,col3a,col4=st.columns([1,1,4])
        col3a.metric("GRN Amount", f"{total_grn/1_000_000:,.2f} M")
        with col3.popover("⚙️ Show Filters"):
            col1, col2 = st.columns([1, 1])
            grn_data['Year'] = grn_data['Year'].astype(int)

            year_list1 = sorted(grn_data['Year'].unique())
                # --- Year Filter ---
            start_year, end_year = st.select_slider(
            "Select Year Range",
            options=year_list1,
            value=(year_list1[0], year_list1[-1]),
            key="grn_year_slider"  # unique key
            )
        grn_data_filtered = grn_data[(grn_data['Year'] >= start_year) & (grn_data['Year'] <= end_year)]
        grn_pur_year = grn_data_filtered.groupby('Year')['Amount'].sum().reset_index()
        if grn_pur_year['Year'].dtype != object:
                    grn_pur_year['Year'] = grn_pur_year['Year'].apply(lambda x: str(int(x)))

        # Sort the DataFrame in descending order based on TOTALAMOUNT
        grn_pur_year = grn_pur_year.sort_values(by='Amount', ascending=False)
        grn_pur_year['Year'] = grn_pur_year['Year'].astype(int).astype(str)
        grn_pur_year['Amount'] = (grn_pur_year['Amount'] / 1_000_000).round(1)

                    # Create the bar chart using Plotly
        fig_bar1 = px.bar(grn_pur_year, 
                                    x='Year', 
                                    y='Amount',
                                    text_auto=True,
                                    title='GRN Value OMR (in millions)- Yearly',
                                    color_discrete_sequence=["#006400"])  # Show all year labels
        fig_bar1.update_xaxes(
                        tickmode='array', 
                        tickvals=grn_pur_year['Year'], 
                        ticktext=grn_pur_year['Year'] )
        fig_bar1.update_yaxes(tickformat=",")

        fig_bar1.update_layout(
            autosize=True,
            height=500   # 👈 match the CSS height
        )
    # --- New Pie Chart ---
        fig_pie1 = px.pie(
                grn_pur_year, 
                names='Year', 
                values='Amount',
                title='Net Amount GRN',
                hole=0.4,   # donut style
                color_discrete_sequence=px.colors.sequential.Greens  # gradient green
        )
        fig_pie1.update_traces(textinfo='percent+label')

        fig_pie1.update_layout(
                autosize=True,
                height=500   # 👈 match the CSS height
            )
        col1, col2 = st.columns([3,2])
        with col1:
                st.plotly_chart(fig_bar1, use_container_width=True)
        with col2:
                st.plotly_chart(fig_pie1, use_container_width=True)

    
    with tab5:
        top_projects = lpo_grn_gross_amount
        sort_by='PO_Value'
        top_projects = top_projects.sort_values(sort_by, ascending=True)
        col3,col3a,col4=st.columns([1.4,5,3])
        #col3.metric("GRN Amount", f"{total_grn/1_000_000:,.2f} M")
        with col3.popover("⚙️ Show Filters"):
            col1, col2 = st.columns([1, 1])
            top_n_project= st.slider("Number of Top Projects", min_value=5, max_value=50, value=10,key="top_n_projects_slider")
        top_projects = top_projects.nlargest(top_n_project, 'PO_Value')

     
        #top_projects['Project'] = top_projects['Project'].astype(int).astype(str)
        top_projects['PO_Value'] = (top_projects['PO_Value'] / 1_000_000).round(1)
        top_projects['GRN_Value'] = (top_projects['GRN_Value'] / 1_000_000).round(1)

                    # Create the bar chart using Plotly
        fig_bar5 = px.bar(top_projects, 
                                    x='Project', 
                                    y=['PO_Value','GRN_Value'],
                                    text_auto=True,
                                    title=f'Top {top_n_project} Projects',
                                    color_discrete_sequence=["#006400"])  # Show all year labels
        fig_bar5.update_xaxes(
                        tickmode='array', 
                        tickvals=top_projects['Project'], 
                        ticktext=top_projects['Project'] )
        fig_bar5.update_yaxes(tickformat=",")

        fig_bar5.update_layout(
            autosize=True,
            height=500   # 👈 match the CSS height
        )
    # --- New Pie Chart ---
        fig_pie5 = px.pie(
                top_projects, 
                names='Project', 
                values='PO_Value',
                title=f'Top {top_n_project} Projects',
                hole=0.4,   # donut style
                color_discrete_sequence=px.colors.sequential.Greens  # gradient green
                )
        fig_pie5.update_traces(textinfo='percent+label')

        fig_pie5.update_layout(
                autosize=True,
                height=500   # 👈 match the CSS height
            )
        col1, col2 = st.columns([3,2])
        with col1:
                st.plotly_chart(fig_bar5, use_container_width=True)
                
        with col2:
                st.plotly_chart(fig_pie5, use_container_width=True)

        
    with tab6:
        top_projects = lpo_grn_net_values
        
        sort_by='PO_Value'
        top_projects = top_projects.sort_values(sort_by, ascending=True)
        col3,col3a,col4=st.columns([1.4,5,3])
        #col3.metric("GRN Amount", f"{total_grn/1_000_000:,.2f} M")
        with col3.popover("⚙️ Show Filters"):
            col1, col2 = st.columns([1, 1])
            top_n_project= st.slider("Number of Top Projects", min_value=5, max_value=50, value=20,key="top_n_projects_slider2")
        top_projects = top_projects.nlargest(top_n_project, 'PO_Value')

     
        #top_projects['Project'] = top_projects['Project'].astype(int).astype(str)
        top_projects['PO_Value'] = (top_projects['PO_Value'] / 1_000_000).round(1)
        top_projects['GRN_Value'] = (top_projects['GRN_Value'] / 1_000_000).round(1)
        

                    # Create the bar chart using Plotly
        fig_bar5 = px.bar(top_projects, 
                                    x='Project', 
                                    y=['PO_Value','GRN_Value'],
                                    text_auto=True,
                                    title=f'Top {top_n_project} Projects',
                                    color_discrete_sequence=["#006400"])  # Show all year labels
        fig_bar5.update_xaxes(
                        tickmode='array', 
                        tickvals=top_projects['Project'], 
                        ticktext=top_projects['Project'] )
        fig_bar5.update_yaxes(tickformat=",")

        fig_bar5.update_layout(
            autosize=True,
            height=500   # 👈 match the CSS height
        )
    # --- New Pie Chart ---
        fig_pie5 = px.pie(
                top_projects, 
                names='Project', 
                values='PO_Value',
                title=f'Top {top_n_project} Projects',
                hole=0.4,   # donut style
                color_discrete_sequence=px.colors.sequential.Greens  # gradient green
                )
        fig_pie5.update_traces(textinfo='percent+label')

        fig_pie5.update_layout(
                autosize=True,
                height=500   # 👈 match the CSS height
            )
        col1, col2 = st.columns([3,2])
        with col1:
                st.plotly_chart(fig_bar5, use_container_width=True)
                
        with col2:
                st.plotly_chart(fig_pie5, use_container_width=True)
